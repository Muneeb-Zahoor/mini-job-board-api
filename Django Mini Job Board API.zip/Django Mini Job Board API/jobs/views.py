from django.shortcuts import render
from rest_framework import permissions, viewsets, generics, status, request
from rest_framework.response import Response
from rest_framework.decorators import action
from rest_framework.views import APIView
from django_filters.rest_framework import DjangoFilterBackend
from .models import Company, Job
from .permissions import IsOwnerCompany
from .serializers import CompanySerializer, UserSerializer, JobSerializer, JobApplicationSerializer
from .filters import JobFilter

# Create your views here.
class CompanyViewSet(viewsets.ModelViewSet):
    queryset = Company.objects.all()
    serializer_class = CompanySerializer
    
    # 1. Permissions apply kerna
    def get_permissions(self):
        # POST/Create ke liye: Sirf login user ki ijazat hai.
        if self.action == 'create':
            return [permissions.IsAuthenticated()] 
        # PUT/PATCH/DELETE (manage) ke liye: Custom Owner check zaroori hai.
        return [IsOwnerCompany()]
    
    # 2. Creator field ko automatic set karna (Interview Essential)
    def perform_create(self, serializer):
        # Jab company create ho rahi ho (POST request), toh created_by field ko 
        # request bhejney walay user (request.user) par set kar do.
        serializer.save(created_by=self.request.user)
        
# generics.CreateAPIView sirf POST request ko handle karne ke liye banaya gaya hai.
class RegisterUserView(generics.CreateAPIView):
    serializer_class = UserSerializer
    # Permission: Koi bhi user register kar sakta hai, is liye AllowAny
    permission_classes = [permissions.AllowAny]

# Job ViewSet
class JobViewSet(viewsets.ModelViewSet):
    # created_at ke hisab se latest jobs pehle dikheingi
    queryset = Job.objects.all().order_by('-created_at') 
    serializer_class = JobSerializer
    
    # 1. Permissions: Har koi dekh sakta hai (GET). Sirf login user POST kar sakta hai.
    permission_classes = [permissions.IsAuthenticatedOrReadOnly] 
    
    # 2. Filtering ko activate karein
    filter_backends = (DjangoFilterBackend,)
    filterset_class = JobFilter
    
    # 3. Custom Logic: POST /api/jobs/ (Owner Check)
    def perform_create(self, serializer):
        # User ne jo 'company' ID bhejhi hai (maslan: 5), woh nikalte hain.
        company_id = self.request.data.get('company')
        
        # Validation Check: Kya request bhejney wala user us company ka created_by hai?
        try:
            # Hum Company model mein check karte hain: ID match kare aur created_by bhi request user ho.
            company = Company.objects.get(id=company_id, created_by=self.request.user)
        except Company.DoesNotExist:
            # Agar company nahi milti ya user maalik nahi hai, toh 403 Forbidden error bhejte hain.
            # Yahan 400 ya 403 dono chalte hain, lekin 403 permission ke liye zyada behtar hai.
            raise permissions.PermissionDenied("You do not own this company, or the company ID is invalid for job creation.")

        # Agar check pass ho jaye, toh job create kar do aur company field ko set kar do.
        serializer.save(company=company)
        
    # 4. Custom Action: POST /api/jobs/{id}/apply/
    @action(detail=True, methods=['post'], permission_classes=[permissions.IsAuthenticated])
    def apply(self, request, pk=None):
        job = self.get_object()
        data = {
            'job': job.id,
            'applicant': request.user.id,
            'coverletter': request.data.get('cover_letter','')
        }
        serializer = JobApplicationSerializer(data=data)
        serializer.is_valid(raise_exception=True)
        
        try:
            # serializer.save() database me data save kerta ha
            serializer.save(job=job, applicant=request.user)
            return Response(
                {'detail': 'Application Submitted Successfully'},
                status = status.HTTP_201_CREATED
            )
        except Exception as e:
            if 'unique_together' in str(e):
                return Response(
                    {'detail': 'You have already applied for this job'},
                    status = status.HTTP_400_BAD_REQUEST
                )
            return Response(
                {'detail': 'An error occured during your submission'},
                status=status.HTTP_400_BAD_REQUEST
            ) 
            
# Home URL ke liye view
class APIRootView(APIView):
    # GET request ko handle karein
    # Permission ko AllowAny set karna zaroori hai
    permission_classes = [permissions.AllowAny]
    
    def get(self, request):
        data = {
            "project_title": "Mini Job Board API (Django REST Framework)",
            "status": "Ready for Testing",
            "version": "1.0",
            "endpoints": {
                "--- Authentication ---": "-------------------------",
                "1. Register User": "POST /api/register/ (Payload: username, email, password)",
                "2. Get Token (Login)": "POST /api/token/ (Payload: username, password) -> Returns ACCESS & REFRESH Token",
                "3. Refresh Token": "POST /api/token/refresh/ (Payload: refresh) -> Returns New ACCESS Token",
                
                "--- Job Board APIs ---": "-------------------------",
                "4. Manage Companies": "CRUD operations on /api/companies/",
                "   -> Create Company": "POST /api/companies/ (Auth Required. Only owner can manage his company)",
                "5. Manage Jobs": "CRUD operations on /api/jobs/",
                "   -> List Jobs": "GET /api/jobs/ (Filtering: ?location=Lahore&company_name=Acme)",
                "   -> Create Job": "POST /api/jobs/ (Auth Required. User must own the Company ID provided)",
                "6. Apply to Job": "POST /api/jobs/{id}/apply/ (Auth Required. Payload: cover_letter. Prevents Duplicates.)",
            },
            "tasks_completed": [
                "All 3 API Endpoints",
                "JWT Authentication (Objective 2)",
                "Filtering on Jobs (Location/Company)",
                "Signals Task (Default Company on Registration)",
                "Custom Owner Permissions (Company & Job Creation)",
                "Bonus: Prevent Duplicate Applications"
            ],
            "note": "Use the ACCESS token in the Authorization: Bearer <token> header for authenticated requests."
        }
        return Response(data, status=status.HTTP_200_OK)