import django_filters
from .models import Job

class JobFilter(django_filters.FilterSet):
    # 'company__name' ka matlab hai ke Job Model ki ForeignKey 'company' ke zariye Company Model ke 'name' field par filter karo.
    company_name = django_filters.CharFilter(
        field_name='company__name',
        lookup_expr='icontains' # icontains: Case-insensitive partial match
    )
    
    class Meta:
        model = Job
        fields = [
            'location', # Simple exact match for location
            'company_name' # Isay humne custom define kiya hai
        ]
# Is se user yeh URLs use kar sake ga:
# /api/jobs/?location=Lahore
# /api/jobs/?company_name=TCS