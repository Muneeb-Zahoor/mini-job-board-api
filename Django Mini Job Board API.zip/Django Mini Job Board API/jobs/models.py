from django.db import models
from django.contrib.auth.models import User # Built-in user model

# 1. Company Model
class Company(models.Model):
    name = models.CharField(max_length=250)
    description = models.TextField()
    # ForeignKey (One-to-Many) relationship with User
    # on_delete=models.CASCADE: Agar User delete ho jaye, toh Company bhi delete ho jaye gi.
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    def __str__(self):
        return self.name

# 2. Job Model
class Job(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    location = models.CharField(max_length=100)
    # ForeignKey to Company: Ek Job sirf ek Company se related ho sakti hai.
    company = models.ForeignKey(Company, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    # Current Time Add ho jaye ga
    def __str__(self):
        return f"{self.title} at {self.company.name}"
    
# 3. Job Application Model
class JobApplication(models.Model):
    # ForignKey to Job
    job = models.ForeignKey(Job, on_delete=models.CASCADE)
    # ForignKey to User
    applicant = models.ForeignKey(User, on_delete=models.CASCADE)
    cover_letter = models.TextField()
    applied_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        # Bonus Task: Prevent duplicate job applications by the same user
        # user aur job ka combination hamesha unique hona chahiye
        unique_together = ('job', 'applicant')
    def __str__(self):
        return f"{self.applicant.username} applied for {self.job.title}"