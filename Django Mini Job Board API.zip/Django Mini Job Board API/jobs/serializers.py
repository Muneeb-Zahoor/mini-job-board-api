from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Company, Job, JobApplication

# 1. User Registration Serializer
# Ye buildin User Model ko handle kere ga
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'password')
        # password sirf likhne ke liye ho par jab data wapas jaye toh dikhai na de.
        extra_kwargs = {'password': {'write_only': True}}
    # Validation ke baad new user ko create kerna
    def create(self, validated_data):
        user = User.objects.create_user( 
            username=validated_data['username'],
            email=validated_data.get('email', ''),
            password=validated_data['password']
        )
        return user

# 2. Company Serializer
class CompanySerializer(serializers.ModelSerializer):
    # created_by field sirf parhne ke liye hoga taake client isay change na kar sake.
    # Interview Point: Jab aap ForeignKey field ko sirf parhne ke liye define karte hain, 
    # toh woh Model ki bajaye Serializer ka field ban jata hai.
    created_by = serializers.ReadOnlyField(source='created_by.username')
    
    class Meta:
        model = Company
        # created_at ko bhi sirf parhne ke liye rakha gaya hai
        fields = "__all__" # (name, description, created_by, created_at, id)

# 3. Job Serializer
class JobSerializer(serializers.ModelSerializer):
    company_name = serializers.CharField(source='company.name', read_only=True)
    
    class Meta:
        model = Job
        fields = "__all__"
        
# 4. Job Application Serializer
class JobApplicationSerializer(serializers.ModelSerializer):
    applicant = serializers.ReadOnlyField(source='applicant.username')
    job_title = serializers.ReadOnlyField(source='job.title')
    
    class Meta:
        model = JobApplication
        fields = ('job', 'id', 'job_title', 'applicant', 'cover_letter', 'applied_at')
        read_only_fields = ('id', 'applied_at', 'applicant', 'job_title')