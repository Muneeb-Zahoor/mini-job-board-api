from django.db.models.signals import post_save
from django.dispatch import receiver
from django.contrib.auth.models import User
from .models import Company

@receiver(post_save, sender=User)
def create_default_company(sender, instance, created, **kwargs):
    if created:
        Company.objects.create(
            name = f"Default Company for {instance.username}",
            description = f"This is the default company for {instance.username}.",
            created_by = instance
        )