from rest_framework import permissions

# Ye class check kere gi ke user company ka owner ha ye nai
class IsOwnerCompany(permissions.BasePermission):
    # 1. has_object_permission function istemaal kerin ge
    def has_object_permission(self, request, view, obj):
        # A. Safest Check: Read-only methods (GET, HEAD, OPTIONS) ke liye hamesha ijazat hai.
        # Har koi Company list dekh sakta hai.
        if request.method in permissions.SAFE_METHODS:
            return True
        # B. Write Check: PUT, PATCH, DELETE ke liye check karo ke user object ka owner hai.
        # obj.created_by == request.user
        return obj.created_by == request.user